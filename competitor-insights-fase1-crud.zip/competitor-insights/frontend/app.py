"""Página principal do Competitor Insights: dashboard (esqueleto da Fase 0)."""
import streamlit as st

from services.api_client import ApiClient

st.set_page_config(page_title="Competitor Insights", layout="wide")

api = ApiClient()

if "access_token" not in st.session_state:
    st.warning("Faça login para continuar.")
    st.page_link("pages/1_Login.py", label="Ir para o login")
    st.stop()

user = api.get_current_user(st.session_state["access_token"])

st.sidebar.title("Competitor Insights")
st.sidebar.write(f"Olá, {user['name']}")
st.sidebar.caption(f"Papel: {user['role']}")

st.title("Dashboard")
st.caption("Esqueleto da Fase 0 — os widgets reais (concorrentes, alterações, alertas) entram na Fase 1.")

col1, col2, col3, col4 = st.columns(4)
col1.metric("Concorrentes monitorados", "0")
col2.metric("Última atualização", "—")
col3.metric("Alterações detectadas", "0")
col4.metric("Alertas importantes", "0")

st.info("Cadastre seu primeiro concorrente para começar a receber insights.")
