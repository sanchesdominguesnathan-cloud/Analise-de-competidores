"""Página de login e registro de conta."""
import httpx
import streamlit as st

from services.api_client import ApiClient

st.set_page_config(page_title="Login — Competitor Insights", layout="centered")
api = ApiClient()

st.title("Competitor Insights")

login_tab, register_tab = st.tabs(["Entrar", "Criar conta"])

with login_tab:
    with st.form("login_form"):
        email = st.text_input("E-mail")
        password = st.text_input("Senha", type="password")
        submitted = st.form_submit_button("Entrar")

    if submitted:
        try:
            tokens = api.login(email, password)
            st.session_state["access_token"] = tokens["access_token"]
            st.success("Login realizado com sucesso.")
            st.switch_page("app.py")
        except httpx.HTTPStatusError:
            st.error("E-mail ou senha inválidos.")

with register_tab:
    with st.form("register_form"):
        company_name = st.text_input("Nome da empresa")
        name = st.text_input("Seu nome")
        reg_email = st.text_input("E-mail", key="reg_email")
        reg_password = st.text_input("Senha", type="password", key="reg_password")
        reg_submitted = st.form_submit_button("Criar conta")

    if reg_submitted:
        try:
            api.register(name, reg_email, reg_password, company_name)
            st.success("Conta criada. Agora faça login na aba ao lado.")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 409:
                st.error("Esse e-mail já está cadastrado.")
            else:
                st.error("Não foi possível criar a conta.")
