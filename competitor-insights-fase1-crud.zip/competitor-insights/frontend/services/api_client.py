"""Cliente HTTP simples para o frontend consumir a API do backend."""
import os

import httpx

API_BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000")


class ApiClient:
    """Encapsula as chamadas HTTP à API do Competitor Insights."""

    def __init__(self, base_url: str = API_BASE_URL) -> None:
        self._base_url = base_url

    def login(self, email: str, password: str) -> dict:
        """Autentica o usuário e retorna os tokens JWT."""
        response = httpx.post(f"{self._base_url}/api/v1/auth/login", json={"email": email, "password": password})
        response.raise_for_status()
        return response.json()

    def register(self, name: str, email: str, password: str, company_name: str) -> dict:
        """Registra uma nova empresa e seu usuário administrador."""
        response = httpx.post(
            f"{self._base_url}/api/v1/auth/register",
            json={"name": name, "email": email, "password": password, "company_name": company_name},
        )
        response.raise_for_status()
        return response.json()

    def get_current_user(self, access_token: str) -> dict:
        """Busca os dados do usuário autenticado."""
        response = httpx.get(
            f"{self._base_url}/api/v1/auth/me",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        response.raise_for_status()
        return response.json()
