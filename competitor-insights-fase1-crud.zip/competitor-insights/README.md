# Competitor Insights

Plataforma de inteligência competitiva: cadastre concorrentes e receba automaticamente
insights sobre mudanças na presença digital deles (site, blog, notícias, redes sociais,
vagas, preços, tecnologias, SEO e domínio).

> Este repositório está iniciando a **Fase 1 (MVP)** do roadmap: a fundação de
> infraestrutura/autenticação (Fase 0) está completa, e o CRUD de concorrentes já
> está implementado. As demais funcionalidades (scrapers, alertas, índices
> competitivos, resumo por IA) chegam nas próximas etapas — veja `docs/architecture/`.

[![backend-ci](https://github.com/sanchesdominguesnathan-cloud/Comepetitor-analyser/actions/workflows/backend-ci.yml/badge.svg)](https://github.com/sanchesdominguesnathan-cloud/Comepetitor-analyser/actions/workflows/backend-ci.yml)

## Arquitetura

```
Frontend (Streamlit) → Backend API (FastAPI) → Workers (Celery/APScheduler) → Scrapers
                              ↓
                    PostgreSQL + Redis
                              ↓
                    Camada de IA (abstrata, plugável)
```

Ver detalhes completos em `docs/architecture/competitor-insights-planejamento.md`.

## Estrutura do repositório

```
competitor-insights/
├── backend/       # API FastAPI (camadas: api, services, repositories, models, ai, scrapers, workers)
├── frontend/       # Streamlit
├── infra/          # docker-compose.yml
├── .env.example
└── docs/
```

## Como rodar localmente (Docker)

1. Copie o arquivo de variáveis de ambiente:
   ```bash
   cp .env.example .env
   ```
   Ajuste `JWT_SECRET_KEY` para um valor forte antes de qualquer uso além do local.

2. Suba os serviços:
   ```bash
   cd infra
   docker compose up --build
   ```

3. Acesse:
   - API: http://localhost:8000/docs (Swagger gerado automaticamente pelo FastAPI)
   - Frontend: http://localhost:8501

O container do backend já roda `alembic upgrade head` automaticamente antes de subir a API.

## Como rodar sem Docker (desenvolvimento)

**Backend:**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
# suba um Postgres e um Redis locais, ajuste DATABASE_URL/REDIS_URL no .env
alembic upgrade head
uvicorn app.main:app --reload
```

**Testes do backend** (usam SQLite em memória, não precisam de Postgres):
```bash
cd backend
pytest -v
```

**Frontend:**
```bash
cd frontend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export API_BASE_URL=http://localhost:8000
streamlit run app.py
```

## Endpoints implementados

**Autenticação**
- `POST /api/v1/auth/register` — cria a empresa (tenant) e o primeiro usuário (admin)
- `POST /api/v1/auth/login` — retorna access/refresh token (JWT)
- `GET /api/v1/auth/me` — dados do usuário autenticado

**Concorrentes** (protegidos por JWT; escrita restrita a `admin`/`manager`, leitura liberada a todos os papéis)
- `GET /api/v1/competitors` — lista os concorrentes da empresa do usuário autenticado
- `POST /api/v1/competitors` — cadastra um concorrente (com canais e palavras-chave opcionais)
- `GET /api/v1/competitors/{id}` — busca um concorrente (404 se for de outra empresa)
- `PATCH /api/v1/competitors/{id}` — atualização parcial
- `DELETE /api/v1/competitors/{id}` — remoção

Todos os endpoints de concorrentes são isolados por `company_id` — um usuário nunca
consegue ler ou alterar dados de outra empresa, mesmo sabendo o UUID.

## Convenções de código

- PEP8, type hints e docstrings em todo o código Python.
- Camadas nunca são puladas: router → service → repository → model. Nenhuma query SQL direta em router ou service.
- Nenhuma chamada de IA fora de `app/ai/`.
- Toda tabela de negócio é isolada por tenant (`company_id`).
- Migrations sempre via Alembic — nunca alterar o schema manualmente.

## Status por fase

| Fase | Escopo | Status |
|---|---|---|
| Fase 0 | Infra, auth, esqueleto de camadas, CI | Concluída |
| Fase 1 | MVP: cadastro de concorrentes, scraper de site, dashboard, resumo IA | Em andamento (CRUD de concorrentes completo e testado) |
| Fase 2 | V1: blog, redes sociais, vagas, preços, agendamento | Não iniciado |
| Fase 3 | V2: SEO avançado, domínio, tech stack, score final | Não iniciado |
| Fase 4 | V3: multi-provider IA, carga, exportação, API pública | Não iniciado |
