"""Migration: competitors, competitor_channels e competitor_keywords

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-02
"""
from collections.abc import Sequence

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision: str = "0002"
down_revision: str | None = "0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Cria as tabelas de concorrentes, seus canais digitais e palavras-chave."""
    op.create_table(
        "competitors",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "company_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("companies.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("website", sa.String(length=500), nullable=True),
        sa.Column("category", sa.String(length=120), nullable=True),
        sa.Column("segment", sa.String(length=120), nullable=True),
        sa.Column("location", sa.String(length=255), nullable=True),
        sa.Column("logo_url", sa.String(length=500), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_competitors_company_id", "competitors", ["company_id"])

    op.create_table(
        "competitor_channels",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "competitor_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("competitors.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("channel_type", sa.String(length=30), nullable=False),
        sa.Column("url", sa.String(length=500), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint(
            "channel_type IN ('linkedin','instagram','facebook','x','youtube','tiktok','blog')",
            name="ck_competitor_channels_channel_type",
        ),
    )
    op.create_index("ix_competitor_channels_competitor_id", "competitor_channels", ["competitor_id"])
    op.create_unique_constraint(
        "uq_competitor_channels_competitor_type",
        "competitor_channels",
        ["competitor_id", "channel_type"],
    )

    op.create_table(
        "competitor_keywords",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "competitor_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("competitors.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("keyword", sa.String(length=120), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_competitor_keywords_competitor_id", "competitor_keywords", ["competitor_id"])
    op.create_unique_constraint(
        "uq_competitor_keywords_competitor_keyword",
        "competitor_keywords",
        ["competitor_id", "keyword"],
    )


def downgrade() -> None:
    """Reverte a criação das tabelas de concorrentes."""
    op.drop_table("competitor_keywords")
    op.drop_table("competitor_channels")
    op.drop_index("ix_competitors_company_id", table_name="competitors")
    op.drop_table("competitors")
