"""Testes do fluxo de autenticação: registro, login e rota protegida /me."""


def test_register_creates_company_and_admin_user(client):
    response = client.post(
        "/api/v1/auth/register",
        json={
            "name": "Ana Silva",
            "email": "ana@empresa.com",
            "password": "senha-forte-123",
            "company_name": "Empresa Exemplo",
        },
    )
    assert response.status_code == 201
    body = response.json()
    assert body["email"] == "ana@empresa.com"
    assert body["role"] == "admin"


def test_register_duplicate_email_fails(client):
    payload = {
        "name": "Ana Silva",
        "email": "ana@empresa.com",
        "password": "senha-forte-123",
        "company_name": "Empresa Exemplo",
    }
    client.post("/api/v1/auth/register", json=payload)
    response = client.post("/api/v1/auth/register", json=payload)
    assert response.status_code == 409


def test_login_and_access_protected_route(client):
    client.post(
        "/api/v1/auth/register",
        json={
            "name": "Ana Silva",
            "email": "ana@empresa.com",
            "password": "senha-forte-123",
            "company_name": "Empresa Exemplo",
        },
    )

    login_response = client.post(
        "/api/v1/auth/login",
        json={"email": "ana@empresa.com", "password": "senha-forte-123"},
    )
    assert login_response.status_code == 200
    access_token = login_response.json()["access_token"]

    me_response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    assert me_response.status_code == 200
    assert me_response.json()["email"] == "ana@empresa.com"


def test_login_with_wrong_password_fails(client):
    client.post(
        "/api/v1/auth/register",
        json={
            "name": "Ana Silva",
            "email": "ana@empresa.com",
            "password": "senha-forte-123",
            "company_name": "Empresa Exemplo",
        },
    )
    response = client.post(
        "/api/v1/auth/login",
        json={"email": "ana@empresa.com", "password": "senha-errada"},
    )
    assert response.status_code == 401
