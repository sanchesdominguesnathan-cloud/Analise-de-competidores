"""Testes do CRUD de concorrentes: criação, listagem, atualização, remoção e isolamento por tenant."""


def test_create_competitor_with_channels_and_keywords(client, auth_headers):
    headers = auth_headers()
    response = client.post(
        "/api/v1/competitors",
        headers=headers,
        json={
            "name": "Concorrente X",
            "website": "https://concorrentex.com",
            "category": "SaaS",
            "channels": [{"channel_type": "linkedin", "url": "https://linkedin.com/company/x"}],
            "keywords": ["crm", "automação"],
        },
    )
    assert response.status_code == 201
    body = response.json()
    assert body["name"] == "Concorrente X"
    assert len(body["channels"]) == 1
    assert body["channels"][0]["channel_type"] == "linkedin"
    assert sorted(body["keywords"], key=lambda k: k["keyword"]) == sorted(
        body["keywords"], key=lambda k: k["keyword"]
    )
    assert {k["keyword"] for k in body["keywords"]} == {"crm", "automação"}


def test_list_competitors_returns_only_current_company(client, auth_headers):
    headers_company_a = auth_headers(email="a@empresa.com", company_name="Empresa A")
    headers_company_b = auth_headers(email="b@empresa.com", company_name="Empresa B")

    client.post(
        "/api/v1/competitors", headers=headers_company_a, json={"name": "Concorrente da Empresa A"}
    )
    client.post(
        "/api/v1/competitors", headers=headers_company_b, json={"name": "Concorrente da Empresa B"}
    )

    response = client.get("/api/v1/competitors", headers=headers_company_a)
    assert response.status_code == 200
    names = [c["name"] for c in response.json()]
    assert names == ["Concorrente da Empresa A"]


def test_get_competitor_from_another_company_returns_404(client, auth_headers):
    headers_company_a = auth_headers(email="a@empresa.com", company_name="Empresa A")
    headers_company_b = auth_headers(email="b@empresa.com", company_name="Empresa B")

    create_response = client.post(
        "/api/v1/competitors", headers=headers_company_a, json={"name": "Concorrente da Empresa A"}
    )
    competitor_id = create_response.json()["id"]

    response = client.get(f"/api/v1/competitors/{competitor_id}", headers=headers_company_b)
    assert response.status_code == 404


def test_update_competitor(client, auth_headers):
    headers = auth_headers()
    create_response = client.post(
        "/api/v1/competitors", headers=headers, json={"name": "Nome antigo"}
    )
    competitor_id = create_response.json()["id"]

    response = client.patch(
        f"/api/v1/competitors/{competitor_id}", headers=headers, json={"name": "Nome novo"}
    )
    assert response.status_code == 200
    assert response.json()["name"] == "Nome novo"


def test_delete_competitor(client, auth_headers):
    headers = auth_headers()
    create_response = client.post("/api/v1/competitors", headers=headers, json={"name": "Para remover"})
    competitor_id = create_response.json()["id"]

    delete_response = client.delete(f"/api/v1/competitors/{competitor_id}", headers=headers)
    assert delete_response.status_code == 204

    get_response = client.get(f"/api/v1/competitors/{competitor_id}", headers=headers)
    assert get_response.status_code == 404


def test_viewer_cannot_create_competitor(client, db_session):
    from app.core.security import hash_password
    from app.models.company import Company
    from app.models.user import User, UserRole

    company = Company(name="Empresa Viewer")
    db_session.add(company)
    db_session.flush()
    viewer = User(
        company_id=company.id,
        name="Vinicius Viewer",
        email="viewer@empresa.com",
        hashed_password=hash_password("senha-forte-123"),
        role=UserRole.VIEWER,
    )
    db_session.add(viewer)
    db_session.commit()

    login_response = client.post(
        "/api/v1/auth/login", json={"email": "viewer@empresa.com", "password": "senha-forte-123"}
    )
    headers = {"Authorization": f"Bearer {login_response.json()['access_token']}"}

    response = client.post("/api/v1/competitors", headers=headers, json={"name": "Não deveria criar"})
    assert response.status_code == 403


def test_unauthenticated_request_is_rejected(client):
    response = client.get("/api/v1/competitors")
    assert response.status_code == 401
