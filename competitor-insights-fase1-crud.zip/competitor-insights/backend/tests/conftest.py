"""Fixtures compartilhadas dos testes: banco SQLite em memória e client de teste."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.database import get_db
from app.main import app
from app.models.base import Base


@pytest.fixture()
def db_session():
    """Cria um banco SQLite em memória isolado por teste."""
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    testing_session_local = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    session = testing_session_local()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def client(db_session):
    """TestClient do FastAPI com a dependência de banco substituída pelo SQLite de teste."""

    def _override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture()
def auth_headers(client):
    """Registra uma empresa/usuário admin e retorna uma função que loga e devolve os headers."""

    def _register_and_login(email: str = "ana@empresa.com", company_name: str = "Empresa Exemplo"):
        client.post(
            "/api/v1/auth/register",
            json={
                "name": "Ana Silva",
                "email": email,
                "password": "senha-forte-123",
                "company_name": company_name,
            },
        )
        login_response = client.post(
            "/api/v1/auth/login", json={"email": email, "password": "senha-forte-123"}
        )
        token = login_response.json()["access_token"]
        return {"Authorization": f"Bearer {token}"}

    return _register_and_login
