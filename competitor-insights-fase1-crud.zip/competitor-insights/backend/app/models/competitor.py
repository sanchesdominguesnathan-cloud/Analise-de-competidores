"""Modelo Competitor — o concorrente cadastrado por uma Company (tenant)."""
import uuid

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class Competitor(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Concorrente monitorado por uma empresa cliente (tenant)."""

    __tablename__ = "competitors"

    company_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    website: Mapped[str | None] = mapped_column(String(500), nullable=True)
    category: Mapped[str | None] = mapped_column(String(120), nullable=True)
    segment: Mapped[str | None] = mapped_column(String(120), nullable=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True)
    logo_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)

    channels: Mapped[list["CompetitorChannel"]] = relationship(
        back_populates="competitor", cascade="all, delete-orphan"
    )
    keywords: Mapped[list["CompetitorKeyword"]] = relationship(
        back_populates="competitor", cascade="all, delete-orphan"
    )


class CompetitorChannel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Canal digital de um concorrente (LinkedIn, Instagram, blog etc.)."""

    __tablename__ = "competitor_channels"

    competitor_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("competitors.id", ondelete="CASCADE"), nullable=False, index=True
    )
    channel_type: Mapped[str] = mapped_column(String(30), nullable=False)
    url: Mapped[str] = mapped_column(String(500), nullable=False)

    competitor: Mapped["Competitor"] = relationship(back_populates="channels")


class CompetitorKeyword(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Palavra-chave associada a um concorrente, usada para busca e classificação."""

    __tablename__ = "competitor_keywords"

    competitor_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("competitors.id", ondelete="CASCADE"), nullable=False, index=True
    )
    keyword: Mapped[str] = mapped_column(String(120), nullable=False)

    competitor: Mapped["Competitor"] = relationship(back_populates="keywords")
