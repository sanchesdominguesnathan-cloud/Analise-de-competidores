"""Regras de negócio de Competitor: criação, listagem, atualização e remoção."""
import uuid
from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.models.competitor import Competitor
from app.repositories.competitor_repository import CompetitorRepository
from app.schemas.competitor import CompetitorCreate, CompetitorUpdate


class CompetitorNotFoundError(Exception):
    """Lançada quando o concorrente não existe ou não pertence à empresa do usuário."""


@dataclass
class CompetitorService:
    """Orquestra o CRUD de concorrentes, sempre isolado por `company_id` (multi-tenant)."""

    db: Session

    def list_competitors(self, company_id: uuid.UUID) -> list[Competitor]:
        """Lista os concorrentes ativos da empresa."""
        return CompetitorRepository(self.db).list_by_company(company_id)

    def get_competitor(self, competitor_id: uuid.UUID, company_id: uuid.UUID) -> Competitor:
        """Busca um concorrente da empresa; lança erro se não existir ou for de outra empresa."""
        competitor = CompetitorRepository(self.db).get_by_id(competitor_id, company_id)
        if competitor is None:
            raise CompetitorNotFoundError(f"Concorrente não encontrado: {competitor_id}")
        return competitor

    def create_competitor(self, company_id: uuid.UUID, payload: CompetitorCreate) -> Competitor:
        """Cria um novo concorrente, com seus canais e palavras-chave iniciais."""
        repo = CompetitorRepository(self.db)
        data = payload.model_dump(exclude={"channels", "keywords"})
        channels = [{"channel_type": c.channel_type.value, "url": c.url} for c in payload.channels]
        competitor = repo.create(
            company_id=company_id, data=data, channels=channels, keywords=payload.keywords
        )
        self.db.commit()
        self.db.refresh(competitor)
        return competitor

    def update_competitor(
        self, competitor_id: uuid.UUID, company_id: uuid.UUID, payload: CompetitorUpdate
    ) -> Competitor:
        """Atualiza parcialmente um concorrente da empresa."""
        competitor = self.get_competitor(competitor_id, company_id)
        data = payload.model_dump(exclude_unset=True)
        CompetitorRepository(self.db).update(competitor, data)
        self.db.commit()
        self.db.refresh(competitor)
        return competitor

    def delete_competitor(self, competitor_id: uuid.UUID, company_id: uuid.UUID) -> None:
        """Remove um concorrente da empresa."""
        competitor = self.get_competitor(competitor_id, company_id)
        CompetitorRepository(self.db).delete(competitor)
        self.db.commit()
