"""Regras de negócio de autenticação: registro de conta e login."""
from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.core.security import create_access_token, create_refresh_token, hash_password, verify_password
from app.models.user import User, UserRole
from app.repositories.company_repository import CompanyRepository
from app.repositories.user_repository import UserRepository
from app.schemas.auth import TokenResponse
from app.schemas.user import UserCreate


class InvalidCredentialsError(Exception):
    """Lançada quando e-mail/senha não conferem no login."""


class EmailAlreadyRegisteredError(Exception):
    """Lançada quando o e-mail já está em uso no registro."""


@dataclass
class AuthService:
    """Orquestra registro e login, delegando persistência aos repositories."""

    db: Session

    def register(self, payload: UserCreate) -> User:
        """Cria uma nova Company e o primeiro usuário (admin) dessa empresa."""
        user_repo = UserRepository(self.db)
        company_repo = CompanyRepository(self.db)

        if user_repo.get_by_email(payload.email) is not None:
            raise EmailAlreadyRegisteredError(f"E-mail já cadastrado: {payload.email}")

        company = company_repo.create(name=payload.company_name)
        user = user_repo.create(
            company_id=company.id,
            name=payload.name,
            email=payload.email,
            hashed_password=hash_password(payload.password),
            role=UserRole.ADMIN,
        )
        self.db.commit()
        self.db.refresh(user)
        return user

    def login(self, email: str, password: str) -> TokenResponse:
        """Valida credenciais e emite os tokens de acesso/refresh."""
        user_repo = UserRepository(self.db)
        user = user_repo.get_by_email(email)

        if user is None or not user.is_active or not verify_password(password, user.hashed_password):
            raise InvalidCredentialsError("E-mail ou senha inválidos")

        claims = {"company_id": str(user.company_id), "role": user.role.value}
        return TokenResponse(
            access_token=create_access_token(str(user.id), extra_claims=claims),
            refresh_token=create_refresh_token(str(user.id)),
        )
