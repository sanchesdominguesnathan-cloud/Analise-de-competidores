"""DTOs Pydantic relacionados a autenticação."""
from pydantic import BaseModel, EmailStr


class LoginRequest(BaseModel):
    """Payload de login."""

    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Resposta contendo os tokens JWT emitidos."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
