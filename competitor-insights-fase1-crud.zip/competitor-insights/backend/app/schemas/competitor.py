"""DTOs Pydantic relacionados a Competitor."""
import enum
import uuid

from pydantic import BaseModel, ConfigDict, Field


class ChannelType(str, enum.Enum):
    """Tipos de canal digital suportados no cadastro de concorrentes."""

    LINKEDIN = "linkedin"
    INSTAGRAM = "instagram"
    FACEBOOK = "facebook"
    X = "x"
    YOUTUBE = "youtube"
    TIKTOK = "tiktok"
    BLOG = "blog"


class CompetitorChannelInput(BaseModel):
    """Canal digital enviado na criação/atualização de um concorrente."""

    channel_type: ChannelType
    url: str = Field(min_length=1, max_length=500)


class CompetitorChannelRead(BaseModel):
    """Representação de um canal digital já persistido."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    channel_type: ChannelType
    url: str


class CompetitorKeywordRead(BaseModel):
    """Representação de uma palavra-chave já persistida."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    keyword: str


class CompetitorBase(BaseModel):
    """Campos comuns entre criação e atualização de um concorrente."""

    name: str = Field(min_length=1, max_length=255)
    website: str | None = Field(default=None, max_length=500)
    category: str | None = Field(default=None, max_length=120)
    segment: str | None = Field(default=None, max_length=120)
    location: str | None = Field(default=None, max_length=255)
    logo_url: str | None = Field(default=None, max_length=500)
    notes: str | None = None


class CompetitorCreate(CompetitorBase):
    """Payload de criação de um concorrente, com canais e palavras-chave opcionais."""

    channels: list[CompetitorChannelInput] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)


class CompetitorUpdate(BaseModel):
    """Payload de atualização parcial de um concorrente."""

    name: str | None = Field(default=None, min_length=1, max_length=255)
    website: str | None = Field(default=None, max_length=500)
    category: str | None = Field(default=None, max_length=120)
    segment: str | None = Field(default=None, max_length=120)
    location: str | None = Field(default=None, max_length=255)
    logo_url: str | None = Field(default=None, max_length=500)
    notes: str | None = None
    is_active: bool | None = None


class CompetitorRead(CompetitorBase):
    """Representação pública de um concorrente, com canais e palavras-chave."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    company_id: uuid.UUID
    is_active: bool
    channels: list[CompetitorChannelRead] = Field(default_factory=list)
    keywords: list[CompetitorKeywordRead] = Field(default_factory=list)
