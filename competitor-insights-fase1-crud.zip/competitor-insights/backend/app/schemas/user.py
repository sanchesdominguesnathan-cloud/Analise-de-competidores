"""DTOs Pydantic relacionados a User."""
import uuid

from pydantic import BaseModel, ConfigDict, EmailStr

from app.models.user import UserRole


class UserCreate(BaseModel):
    """Payload de criação de usuário (usado no registro)."""

    name: str
    email: EmailStr
    password: str
    company_name: str


class UserRead(BaseModel):
    """Representação pública de um usuário (nunca inclui a senha)."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    company_id: uuid.UUID
    name: str
    email: EmailStr
    role: UserRole
    is_active: bool
