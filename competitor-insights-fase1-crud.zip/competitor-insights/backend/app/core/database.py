"""Engine e factory de sessões do SQLAlchemy."""
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import get_settings

settings = get_settings()

engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, future=True)


def get_db() -> Generator[Session, None, None]:
    """Dependency do FastAPI: fornece uma sessão de banco por request e garante o fechamento."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
