"""Configuração central de logging da aplicação."""
import logging
import sys

from app.core.config import get_settings


def configure_logging() -> None:
    """Configura o logging raiz com formato consistente para toda a aplicação."""
    settings = get_settings()
    level = logging.DEBUG if settings.debug else logging.INFO

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )

    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers = [handler]

    # Bibliotecas de terceiros ficam mais silenciosas por padrão
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
