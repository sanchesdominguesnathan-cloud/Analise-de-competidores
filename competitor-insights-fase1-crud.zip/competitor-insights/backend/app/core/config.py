"""Configurações centrais da aplicação, carregadas de variáveis de ambiente."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configurações da aplicação. Nunca hardcodar secrets — sempre via env vars."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Competitor Insights"
    environment: str = "development"
    debug: bool = True

    # Banco de dados
    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/competitor_insights"

    # Redis (cache / broker de filas)
    redis_url: str = "redis://localhost:6379/0"

    # Autenticação
    jwt_secret_key: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    refresh_token_expire_days: int = 7

    # Rate limiting
    rate_limit_per_minute: int = 60

    # IA (usado futuramente pela camada app/ai)
    ai_provider: str = "openai"
    ai_api_key: str | None = None

    # CORS
    allowed_origins: list[str] = ["http://localhost:8501"]


@lru_cache
def get_settings() -> Settings:
    """Retorna as configurações como singleton (cacheado)."""
    return Settings()
