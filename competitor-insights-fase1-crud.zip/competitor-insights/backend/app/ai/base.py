"""Interface abstrata da camada de IA — todo provider (OpenAI/Claude/Gemini) a implementa.

Nenhuma outra camada do sistema deve chamar um SDK de IA diretamente: sempre
passar por um AIProvider, resolvido via `get_ai_provider()`. Isso mantém a
lógica de prompt, retries e custo centralizada em um único lugar.
"""
from abc import ABC, abstractmethod


class AIProvider(ABC):
    """Contrato que todo provedor de IA (OpenAI, Claude, Gemini...) deve implementar."""

    @abstractmethod
    def summarize_changes(self, competitor_name: str, changes: list[str]) -> str:
        """Gera um resumo em linguagem natural a partir de uma lista de mudanças detectadas."""

    @abstractmethod
    def classify_sentiment(self, text: str) -> str:
        """Classifica o sentimento de um texto (ex.: notícia) como positivo/neutro/negativo."""
