"""Factory que resolve qual AIProvider usar, com base na configuração da aplicação.

Nesta fase (Fase 0) apenas o contrato e um stub existem — a implementação real
de cada provider (OpenAI/Claude/Gemini) entra na Fase 1, junto do resumo por IA.
"""
from app.ai.base import AIProvider
from app.core.config import get_settings


class NotImplementedAIProvider(AIProvider):
    """Provider placeholder — será substituído pela implementação real na Fase 1."""

    def summarize_changes(self, competitor_name: str, changes: list[str]) -> str:
        raise NotImplementedError("Camada de IA ainda não implementada (prevista para a Fase 1)")

    def classify_sentiment(self, text: str) -> str:
        raise NotImplementedError("Camada de IA ainda não implementada (prevista para a Fase 1)")


def get_ai_provider() -> AIProvider:
    """Resolve o AIProvider configurado via `AI_PROVIDER` (openai/claude/gemini)."""
    settings = get_settings()
    # Fase 0: apenas o placeholder. Cada provider real vira um `elif` aqui,
    # mantendo a troca de provider isolada nesta função.
    _ = settings.ai_provider
    return NotImplementedAIProvider()
