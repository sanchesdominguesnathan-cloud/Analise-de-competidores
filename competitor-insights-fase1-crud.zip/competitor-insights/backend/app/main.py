"""Ponto de entrada da API do Competitor Insights."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.router import api_router
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.middlewares.logging_middleware import RequestLoggingMiddleware

settings = get_settings()
configure_logging()

app = FastAPI(
    title=settings.app_name,
    description="Plataforma de inteligência competitiva.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(RequestLoggingMiddleware)

app.include_router(api_router)


@app.get("/health", tags=["health"])
def health_check() -> dict[str, str]:
    """Endpoint simples de healthcheck, usado por orquestradores e monitoramento."""
    return {"status": "ok", "app": settings.app_name}
