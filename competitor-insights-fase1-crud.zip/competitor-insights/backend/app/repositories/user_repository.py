"""Repository de acesso a dados de User. Isola o service do SQLAlchemy."""
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.user import User, UserRole


class UserRepository:
    """Encapsula todas as operações de banco relacionadas a User."""

    def __init__(self, db: Session) -> None:
        self._db = db

    def get_by_email(self, email: str) -> User | None:
        """Busca um usuário pelo e-mail (usado no login)."""
        stmt = select(User).where(User.email == email)
        return self._db.execute(stmt).scalar_one_or_none()

    def get_by_id(self, user_id: uuid.UUID) -> User | None:
        """Busca um usuário pelo id."""
        return self._db.get(User, user_id)

    def create(
        self,
        *,
        company_id: uuid.UUID,
        name: str,
        email: str,
        hashed_password: str,
        role: UserRole = UserRole.ADMIN,
    ) -> User:
        """Cria e persiste um novo usuário."""
        user = User(
            company_id=company_id,
            name=name,
            email=email,
            hashed_password=hashed_password,
            role=role,
        )
        self._db.add(user)
        self._db.flush()
        return user
