"""Repository de acesso a dados de Competitor. Isola o service do SQLAlchemy."""
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.competitor import Competitor, CompetitorChannel, CompetitorKeyword


class CompetitorRepository:
    """Encapsula todas as operações de banco relacionadas a Competitor."""

    def __init__(self, db: Session) -> None:
        self._db = db

    def _base_query(self):
        return select(Competitor).options(
            selectinload(Competitor.channels), selectinload(Competitor.keywords)
        )

    def list_by_company(self, company_id: uuid.UUID) -> list[Competitor]:
        """Lista todos os concorrentes ativos de uma empresa."""
        stmt = self._base_query().where(
            Competitor.company_id == company_id, Competitor.is_active.is_(True)
        )
        return list(self._db.execute(stmt).unique().scalars().all())

    def get_by_id(self, competitor_id: uuid.UUID, company_id: uuid.UUID) -> Competitor | None:
        """Busca um concorrente pelo id, restrito à empresa dona do dado (isolamento multi-tenant)."""
        stmt = self._base_query().where(
            Competitor.id == competitor_id, Competitor.company_id == company_id
        )
        return self._db.execute(stmt).unique().scalar_one_or_none()

    def create(
        self,
        *,
        company_id: uuid.UUID,
        data: dict,
        channels: list[dict],
        keywords: list[str],
    ) -> Competitor:
        """Cria um concorrente junto de seus canais e palavras-chave."""
        competitor = Competitor(company_id=company_id, **data)
        competitor.channels = [
            CompetitorChannel(channel_type=c["channel_type"], url=c["url"]) for c in channels
        ]
        competitor.keywords = [CompetitorKeyword(keyword=k) for k in keywords]
        self._db.add(competitor)
        self._db.flush()
        return competitor

    def update(self, competitor: Competitor, data: dict) -> Competitor:
        """Atualiza os campos informados de um concorrente já carregado."""
        for field, value in data.items():
            setattr(competitor, field, value)
        self._db.flush()
        return competitor

    def delete(self, competitor: Competitor) -> None:
        """Remove definitivamente um concorrente (e seus canais/keywords, via cascade)."""
        self._db.delete(competitor)
        self._db.flush()
