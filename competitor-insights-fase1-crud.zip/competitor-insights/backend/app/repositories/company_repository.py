"""Repository de acesso a dados de Company. Isola o service do SQLAlchemy."""
from sqlalchemy.orm import Session

from app.models.company import Company


class CompanyRepository:
    """Encapsula todas as operações de banco relacionadas a Company."""

    def __init__(self, db: Session) -> None:
        self._db = db

    def create(self, name: str) -> Company:
        """Cria e persiste uma nova Company."""
        company = Company(name=name)
        self._db.add(company)
        self._db.flush()
        return company
