"""Agrega todos os routers da v1 da API."""
from fastapi import APIRouter

from app.api.v1.auth import router as auth_router
from app.api.v1.competitors import router as competitors_router

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth_router)
api_router.include_router(competitors_router)
