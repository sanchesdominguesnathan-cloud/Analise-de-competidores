"""Rotas de CRUD de concorrentes, isoladas por tenant e protegidas por RBAC."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.core.database import get_db
from app.models.competitor import Competitor
from app.models.user import User, UserRole
from app.schemas.competitor import CompetitorCreate, CompetitorRead, CompetitorUpdate
from app.services.competitor_service import CompetitorNotFoundError, CompetitorService

router = APIRouter(prefix="/competitors", tags=["competitors"])

_can_write = require_roles(UserRole.ADMIN, UserRole.MANAGER)


@router.get("", response_model=list[CompetitorRead])
def list_competitors(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[Competitor]:
    """Lista os concorrentes cadastrados pela empresa do usuário autenticado."""
    return CompetitorService(db).list_competitors(current_user.company_id)


@router.post("", response_model=CompetitorRead, status_code=status.HTTP_201_CREATED)
def create_competitor(
    payload: CompetitorCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(_can_write),
) -> Competitor:
    """Cadastra um novo concorrente para a empresa do usuário autenticado."""
    return CompetitorService(db).create_competitor(current_user.company_id, payload)


@router.get("/{competitor_id}", response_model=CompetitorRead)
def get_competitor(
    competitor_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> Competitor:
    """Busca um concorrente específico da empresa do usuário autenticado."""
    try:
        return CompetitorService(db).get_competitor(competitor_id, current_user.company_id)
    except CompetitorNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.patch("/{competitor_id}", response_model=CompetitorRead)
def update_competitor(
    competitor_id: uuid.UUID,
    payload: CompetitorUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(_can_write),
) -> Competitor:
    """Atualiza parcialmente um concorrente da empresa do usuário autenticado."""
    try:
        return CompetitorService(db).update_competitor(competitor_id, current_user.company_id, payload)
    except CompetitorNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.delete("/{competitor_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_competitor(
    competitor_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(_can_write),
) -> None:
    """Remove um concorrente da empresa do usuário autenticado."""
    try:
        CompetitorService(db).delete_competitor(competitor_id, current_user.company_id)
    except CompetitorNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
