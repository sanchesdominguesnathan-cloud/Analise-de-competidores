# Competitor Insights — Planejamento do Produto

> Documento de arquitetura e planejamento, para aprovação antes de iniciar a implementação.

---

## 1. Arquitetura completa do sistema

O sistema é dividido em **6 camadas desacopladas**, comunicando-se por API/fila, para permitir escalar cada peça independentemente:

| Camada | Responsabilidade | Tecnologia |
|---|---|---|
| **Frontend** | Dashboard, cadastro, visualização | Streamlit (fase 1) → poderá migrar para React no futuro |
| **Backend API** | Regras de negócio, auth, RBAC | FastAPI + SQLAlchemy + Pydantic |
| **Workers** | Execução agendada dos monitoramentos | Celery + Redis (broker) ou APScheduler no MVP |
| **Scrapers** | Coleta de dados públicos por tipo de fonte | Módulos Python independentes (site, redes, vagas, notícias, SEO, domínio) |
| **Camada de IA** | Resumo, sentimento, scoring | Módulo abstrato `ai_provider` plugável (OpenAI/Claude/Gemini) |
| **Dados** | Persistência e cache | PostgreSQL (fonte da verdade) + Redis (fila/cache) |

**Princípios da arquitetura:**
- Backend nunca faz scraping diretamente — delega a workers via fila.
- Workers gravam **snapshots** de cada coleta; a comparação com o snapshot anterior é o que gera "mudança detectada".
- A camada de IA é chamada apenas pelos *services*, nunca pelos routers ou scrapers diretamente — evita chamadas de IA espalhadas pelo código.
- Multi-tenant desde o início: toda tabela relevante tem `company_id`, preparando para milhares de clientes.

As duas visualizações acima resumem: **(1)** o fluxo funcional de ponta a ponta (cadastro → agendamento → coleta → detecção/IA → alertas) e **(2)** a divisão em camadas de arquitetura.

---

## 2. Fluxograma das funcionalidades

Ver diagrama interativo acima ("fluxo de monitoramento"). Resumo textual do ciclo:

1. Empresa cadastra um concorrente (site + redes + fontes).
2. O agendador (diário/semanal/mensal/sob demanda) dispara os jobs de coleta.
3. Os scrapers especializados coletam: website, blog, notícias, redes sociais, vagas, preços, tecnologias, SEO, domínio.
4. O motor de detecção compara o snapshot novo com o último snapshot salvo; toda mudança relevante vira um registro de `change_event`.
5. A camada de IA gera um resumo em linguagem natural e recalcula os índices (atividade, inovação, expansão, marketing, contratação, conteúdo, crescimento) e o score final.
6. O sistema dispara alertas (por regra) e atualiza o dashboard.

---

## 3. Modelagem do banco de dados (visão inicial)

Banco relacional **PostgreSQL**, normalizado (3FN), com tabelas principais agrupadas por domínio. Nesta fase apresento apenas o **modelo conceitual** (entidades e relacionamentos); o DDL completo com constraints, índices e triggers será entregue na etapa de implementação do banco.

**Domínio: Contas e acesso**
- `companies` (tenant) — 1:N com `users`
- `users` — role (admin/manager/viewer), FK `company_id`
- `audit_logs` — FK `user_id`, ação, entidade, timestamp

**Domínio: Concorrentes**
- `competitors` — FK `company_id`; nome, site, categoria, segmento, localização, logo, observações
- `competitor_channels` — FK `competitor_id`; tipo (linkedin/instagram/facebook/x/youtube/tiktok/blog), url
- `competitor_keywords` — FK `competitor_id`; palavra-chave

**Domínio: Monitoramento de website/SEO**
- `website_snapshots` — FK `competitor_id`; timestamp, hash de conteúdo, meta title/description, headings, keywords
- `website_changes` — FK `competitor_id`, `snapshot_id`; tipo de mudança (preço/produto/banner/menu/rodapé/faq/política/vaga/equipe/contato), diff

**Domínio: Preços e produtos**
- `products` — FK `competitor_id`; nome, categoria, ativo/removido
- `price_history` — FK `product_id`; preço, moeda, data, tipo de evento (aumento/redução/promoção/cupom)
- `plans` — FK `competitor_id`; nome, preço, features, status

**Domínio: Conteúdo**
- `blog_posts` — FK `competitor_id`; título, autor, categoria, tags, resumo IA, data
- `news_mentions` — FK `competitor_id`; título, resumo, fonte, link, sentimento, categoria, data
- `social_posts` — FK `competitor_channel_id`; conteúdo, curtidas, comentários, visualizações, hashtags, data
- `social_metrics_snapshot` — FK `competitor_channel_id`; seguidores, frequência de posts, engajamento, data

**Domínio: Vagas**
- `job_postings` — FK `competitor_id`; título, área, cidade, senioridade, modalidade, tecnologias, faixa salarial, fonte (LinkedIn/Gupy/Greenhouse/Lever/site), status (aberta/fechada)

**Domínio: Tecnologia e domínio**
- `tech_stack_detections` — FK `competitor_id`; categoria (framework/analytics/cms/cdn/chatbot...), nome da tecnologia, data de detecção
- `domain_monitoring` — FK `competitor_id`; expiração, DNS, SSL, subdomínios, data da verificação

**Domínio: Inteligência e alertas**
- `change_events` — FK `competitor_id`; tipo, origem (site/blog/redes/vagas/preço/...), resumo IA, importância, data
- `alerts` — FK `company_id`, `competitor_id`, `change_event_id`; tipo, lido/não lido
- `competitive_indexes` — FK `competitor_id`; índice de atividade/inovação/expansão/marketing/contratação/conteúdo/crescimento, score final, período de referência

Todas as tabelas de "snapshot"/"histórico" terão índice composto em `(competitor_id, created_at)` para consultas de série temporal, e as FKs terão `ON DELETE CASCADE` onde fizer sentido (ex.: apagar concorrente apaga seus canais e histórico).

---

## 4. Estrutura de pastas proposta

```
competitor-insights/
├── backend/
│   ├── app/
│   │   ├── api/                # routers (FastAPI)
│   │   │   ├── v1/
│   │   │   │   ├── competitors.py
│   │   │   │   ├── alerts.py
│   │   │   │   ├── dashboard.py
│   │   │   │   └── auth.py
│   │   ├── core/                # config, segurança, logging
│   │   ├── models/               # SQLAlchemy models
│   │   ├── schemas/              # Pydantic DTOs
│   │   ├── repositories/         # Repository Pattern
│   │   ├── services/             # regras de negócio
│   │   ├── ai/                   # camada de IA abstrata (provider-agnostic)
│   │   ├── scrapers/              # um módulo por tipo de fonte
│   │   │   ├── website/
│   │   │   ├── blog/
│   │   │   ├── news/
│   │   │   ├── social/
│   │   │   ├── jobs/
│   │   │   ├── seo/
│   │   │   └── domain/
│   │   ├── workers/               # tasks Celery/APScheduler
│   │   ├── middlewares/
│   │   └── main.py
│   ├── alembic/                   # migrations
│   ├── tests/
│   └── pyproject.toml
├── frontend/
│   ├── pages/                     # páginas Streamlit
│   ├── components/
│   ├── services/                  # client da API
│   └── app.py
├── infra/
│   ├── docker-compose.yml
│   ├── Dockerfile.backend
│   ├── Dockerfile.frontend
│   └── Dockerfile.worker
└── docs/
    └── architecture/
```

---

## 5. Tecnologias escolhidas e justificativa

| Escolha | Por quê |
|---|---|
| **FastAPI** | Assíncrono nativo (importante para scraping/IO), validação automática via Pydantic, ótima DX, alto desempenho |
| **PostgreSQL** | Relacional robusto, suporta JSONB para dados semiestruturados (ex.: payload bruto de scraping), excelente para séries temporais com índices |
| **SQLAlchemy + Alembic** | Padrão de mercado para ORM + migrations versionadas, evita "SQL desorganizado" |
| **Celery + Redis** | Padrão de mercado para filas distribuídas; permite escalar workers horizontalmente; Redis também serve de cache |
| **APScheduler** | Alternativa mais simples ao Celery para o MVP (um único processo agendador), migração para Celery quando o volume crescer |
| **Streamlit** | Acelera o MVP de frontend com pouquíssimo código; arquitetura em páginas separadas mantém organização; troca futura por React não compromete o backend, que é desacoplado via API |
| **JWT + RBAC** | Autenticação stateless, escalável horizontalmente, com papéis (admin/manager/viewer) por empresa |
| **Docker Compose** | Ambiente local reprodutível; caminho direto para deploy em Render/Railway/Fly.io/cloud |
| **Camada de IA abstrata** | Permite trocar entre OpenAI/Claude/Gemini sem reescrever regra de negócio; centraliza custo, retries e logging de chamadas de IA |

---

## 6. Roadmap dividido em fases

**Fase 0 — Fundação (infra e esqueleto)**
Setup do repositório, Docker Compose, banco, migrations iniciais, autenticação, estrutura de camadas vazia porém funcional.

**Fase 1 — MVP**
Cadastro de concorrentes, monitoramento de website (mudanças de texto/preço/produto), dashboard básico, alertas simples, 1 scraper de notícias, resumo por IA (1 provider).

**Fase 2 — V1**
Monitoramento de blog, redes sociais (métricas públicas), vagas, histórico de preços completo, índices competitivos parciais, agendamento configurável.

**Fase 3 — V2**
SEO avançado (Core Web Vitals, schema.org), monitoramento de domínio/SSL/DNS, tecnologias utilizadas (tech stack detection), score final consolidado, RBAC completo.

**Fase 4 — V3**
Multi-provider de IA configurável por cliente, testes de carga para milhares de tenants, exportação de relatórios, API pública para integrações, observabilidade avançada (logs/auditoria/retry refinados).

---

## 7. Backlog priorizado (MVP → V1 → V2 → V3)

**MVP**
1. Autenticação + RBAC básico
2. CRUD de concorrentes (todos os campos de cadastro)
3. Scraper de website (snapshot + diff de texto/preço/produto/banner)
4. Detecção de mudanças + tabela `change_events`
5. Resumo por IA (1 provider, camada abstrata já pronta)
6. Dashboard com métricas essenciais (nº concorrentes, última atualização, alterações, resumo IA)
7. Alertas simples (novo produto, mudança de preço)
8. Docker Compose funcional local

**V1**
9. Scraper de blog + notícias
10. Scraper de redes sociais (métricas públicas)
11. Scraper de vagas (LinkedIn Jobs, Gupy, Greenhouse, Lever)
12. Histórico de preços e planos
13. Agendamento configurável (diário/semanal/mensal/sob demanda) via Celery
14. Alertas expandidos (vaga, post, campanha)

**V2**
15. SEO avançado (meta tags, Open Graph, schema.org, Core Web Vitals)
16. Monitoramento de domínio (expiração, DNS, SSL, subdomínios)
17. Detecção de tecnologias (stack, analytics, CDN, chatbots)
18. Índices competitivos (atividade, inovação, expansão, marketing, contratação, conteúdo, crescimento) + score final
19. RBAC completo com granularidade por módulo

**V3**
20. Suporte multi-provider de IA configurável por cliente
21. Testes de carga e otimizações para milhares de tenants
22. Exportação de relatórios (PDF/Excel)
23. API pública documentada para integrações externas
24. Observabilidade avançada (dashboards de logs, auditoria, SLAs de retry/timeout)

---

## Próximos passos

Este documento cobre os 7 itens solicitados antes de qualquer código. Após sua aprovação (ou ajustes), sugiro começarmos pela **Fase 0**: estrutura de pastas real, Docker Compose, modelos SQLAlchemy e primeira migration Alembic — sempre em etapas pequenas e revisáveis.
